import numpy as np

#Tensorflow packages
import tensorflow as tf
import tensorflow_hub as hub

#other required
import json
import argparse

#For reading image
from PIL import Image

#Logging
import logging
logger=tf.get_logger()
logger.setLevel(logging.ERROR)

#warnings
import warnings
warnings.filterwarnings("ignore")

#Creating a parser
parser=argparse.ArgumentParser(description='parser for image classification')
parser.add_argument("image_path",action="store")
parser.add_argument("saved_model",action="store")
parser.add_argument("--top_k",action="store",default=5,dest="top_k",required=False)
parser.add_argument("--category_names",action="store",dest="category_names")

#adding to results
results=parser.parse_args()

#extracting them here
image_path=results.image_path
saved_model=results.saved_model
cat_file=results.category_names

#seeing results about top_k
if results.top_k==None:
    top_k=5
else:
    top_k=results.top_k

#Defining the methods
def process_image(image):
    image_size=224
    image=tf.cast(image, tf.float32)
    image = tf.image.resize(image,(image_size,image_size))
    image /= 255
    image=image.numpy()
    return image

def predict(image_path, model, top_k=5):
    img = Image.open(image_path)
    test_image_asarray=np.asarray(img)
    process_test_image=process_image(test_image_asarray)
    final_image=np.expand_dims(process_test_image,axis=0)
    probab_predicts=model.predict(final_image)
    fin_probs= -np.partition(-probab_predicts[0],top_k)[:top_k]
    fin_classes= np.argpartition(-probab_predicts[0],top_k)[:top_k]
    return fin_probs,fin_classes

#Applying them
model=tf.keras.models.load_model(saved_model,custom_objects={'KerasLayer':hub.KerasLayer})
image = np.asarray(Image.open(image_path)).squeeze()[0]
probs,classes=predict(image_path, model, top_k)  


#Checking if we are having any classes which are being returned
if cat_file==None:
    with open('label_map.json', 'r') as f1:
         class_names = json.load(f1)
    keys=[str(p+1) for p in list(classes)]
    classes=[class_names.get(j) for j in keys]
else:
    with open(cat_file, 'r') as f2:
         class_names = json.load(f2)
    keys=[str(l+1) for l in list(classes)]
    classes=[class_names.get(h) for h in keys]

#Final printing
print('classes at top are:'.format(top_k))

for i in np.arange(top_k):
    print("class:{}".format(classes[i]))
    print("probability:{:.3%}".format(probs[i]))
    print("\n")
